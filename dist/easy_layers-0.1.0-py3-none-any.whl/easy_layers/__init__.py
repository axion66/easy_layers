"""Easy Layers - A simple neural network layers library."""

__version__ = "0.1.0" 
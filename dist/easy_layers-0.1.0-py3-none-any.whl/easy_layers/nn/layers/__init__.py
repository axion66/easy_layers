"""Neural network layer implementations."""

from .layer import FeedForward

__all__ = ['FeedForward'] 
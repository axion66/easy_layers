"""Easy Layers - A simple neural network layers library."""

__version__ = "0.1.1"

# Import submodules for easier access
from . import nn 
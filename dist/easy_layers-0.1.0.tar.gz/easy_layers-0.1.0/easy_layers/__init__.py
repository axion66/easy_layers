"""Easy Layers - A simple neural network layers library."""

__version__ = "0.1.0"

# Import submodules for easier access
from . import nn 